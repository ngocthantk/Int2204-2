public class Shape {
    protected String color;
    protected boolean filled;
    public Shape(){
        //ham khoi tao mac dinh
        color = "red";
        filled = true;
    }
    public Shape(String color, boolean filled){
        //khoi tao co tham so
        this.color = color; this.filled = filled;
    }
    //cac ham set get
    public void setColor(String color){
        this.color = color;
    }
    public void setFilled(boolean filled){
        this.filled = filled;
    }
    public String getColor(){
        return this.color;
    }
    public boolean isFilled(){
        return this.filled;
    }
    //ham override object
    @Override
    public String toString(){
        return color;
    }
}
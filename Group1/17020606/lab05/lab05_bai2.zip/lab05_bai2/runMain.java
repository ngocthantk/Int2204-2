public class runMain {

    
    public static void main(String[] args) {
        Shape s1 = new Shape("red",false);
        Rectangle r1 = new Rectangle(6.5,4.5,"red",true);
        Circle c1 = new Circle(3.5,"blue",false);
        Square s2 = new Square(5.5,"red",true);
        System.out.println("Area of rectangle, square and circle: ");
        System.out.println(r1.getArea() + " " + s2.getArea() + " " + c1.getArea());
        System.out.println("Perimeter of rectangle, square and circle: ");
        System.out.println(r1.getPerimeter() + " " + s2.getPerimeter() + " " + c1.getPerimeter());
        s2.setSide(10);
        System.out.println(s2.getArea());
    }
    
}
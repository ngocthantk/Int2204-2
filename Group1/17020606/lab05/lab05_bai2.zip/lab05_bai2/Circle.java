import static java.lang.Math.pow;


public class Circle extends Shape{
    private double radius;
    private double  pi = 3.14;
    public Circle(){
        //ham khoi tao mac dinh
        radius = 1.0;
    }
    public Circle(double radius){
        //khoi tao co tham so
        this.radius = radius;
    }
    public Circle(double radius, String color, boolean filled){
        //khoi tao co tham so
        super(color,filled);//goi phuong thuoc cha
        this.radius = radius;
    }
    public double getRadius(){
        return radius;
    }
    public void setRadius(double radius){
        this.radius = radius;
    }
    public double getArea(){
        return pi * (pow(radius,2));
    }
    public double getPerimeter(){
        return 2 * radius * pi;
    }
    @Override
    public String toString(){
        return "Color " + color + " Is filled? " + filled + " Parimeter: " + getPerimeter() + " Area: " + getArea();
    }
}

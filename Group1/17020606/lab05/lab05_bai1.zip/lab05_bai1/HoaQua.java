public class HoaQua {
    protected boolean eatable;
    protected boolean healthy;
    public HoaQua(){
        eatable = healthy = true;
    }
    public HoaQua(boolean eatable, boolean healthy){
        this.eatable = eatable;
        this.healthy = healthy;
    }
    public void setEatable(boolean eatable){
        this.eatable = eatable;
    }
    public void setHealthy(boolean healthy){
        this.healthy = healthy;
    }
    public boolean canEat(){
        return eatable;
    }
    public boolean isHealthy(){
        return healthy;
    }
}

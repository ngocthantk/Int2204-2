public class CamSanh extends QuaCam{
    private String locale;
    private int price;
    public CamSanh(){
        super();
        locale = "Quang Binh";
        price = 14000;
    }
    public CamSanh(boolean eatable, boolean healthy, String color, String shape, String taste, String locale, int price){
        super(eatable,healthy,color,shape,taste);
        this.locale = locale;
        this.shape = shape;
    }
    public void setLocale(String locale){
        this.locale = locale;
    }
    public void setPrice(int price){
        this.price = price;
    }
    public int getPrice(){
        return price;
    }
    public String getLocale(){
        return locale;
    }
}

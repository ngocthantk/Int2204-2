public class QuaTao extends HoaQua{
    protected String color;
    protected String shape;
    protected String taste;
    public QuaTao(boolean eatable, boolean healthy, String color, String shape, String taste){
        super(eatable, healthy);
        this.color = color;
        this.shape = shape;
        this.taste = taste;
    }
    public QuaTao(){
        super();
        color = "Red"; shape = "round"; taste = "juicy";
    }
    public void setColor(String color){
        this.color = color;
    }
    public void setShape(String shape){
        this.shape = shape;
    }
    public void setTaste(String taste){
        this.taste = taste;
    }
    public String getColor(){
        return color;
    }
    public String getShape(){
        return shape;
    }
    public String getTaste(){
        return taste;
    }
}